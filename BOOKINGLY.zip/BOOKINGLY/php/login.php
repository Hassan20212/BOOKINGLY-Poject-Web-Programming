<?php
if (isset($_POST['submit'])) {
    include "connection.php";
    $evname = $_POST['username'];
    $local = $_POST['password'];
    $sql = "SELECT * FROM `usertable` where `username` = '$evname' and `password` = '$local' ;";
    $result = $con->query($sql);


    $row = $result->fetch_assoc();
    if (!$row) {    
        die(
            "Not Found"
        );
        
    }

    if($row['usertype'] == 'user'){
        // header("Location:homepage.php?username=$row[username]");
        header("Location:..\index.html");
        die();
    }elseif($row['usertype'] == 'staff'){
        header("Location:Flight.php");
        die();
    } elseif ($row['usertype'] == 'admin') {
        header("Location:utest.php");
        die();
    }
}
?>
<!DOCTYPE html>
<html>

<head>
    <title> ADD New Event</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="col-lg-6 m-auto">

        <form method="post">

            <br><br>
            <div class="card">

                <div class="card-header bg-primary">
                <h1 class="text-white text-center"> Login </h1>
                </div><br>
                <label> user name: </label>
                <input type="text" name="username" class="form-control"> <br>
                <label> password: </label>
                <input type="password" name="password"  class="form-control"> <br>
                <button class="btn btn-success" type="submit" name="submit">Login</button><br>
                <a type="button" class="btn btn-outline-primary" href="ucreate.php">SignUp</a><br>
                <a  type="button" class="btn btn-outline-primary" href="../index.html">homepage</a><br>


                
            </div>

        </form>
    </div>

</body>

</html>
