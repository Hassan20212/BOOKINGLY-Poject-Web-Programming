<?php
    include "connection.php";
    if(isset($_GET['eventname2'])){
        $id = $_GET['eventname2'];
        $sql = "DELETE FROM hotel WHERE  `eventname2` = '$id'" ;
        // $conn->query($sql);
        if (mysqli_query($con, $sql)) {
            echo "Record deleted successfully";
        } else {
            echo "Error deleting record: " . mysqli_error($con);
        }
        
    }
    header('location: hotel.php');
    exit;
?>