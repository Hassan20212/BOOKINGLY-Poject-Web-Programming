<?php
include "connection.php";
if ($_SERVER["REQUEST_METHOD"] == "GET") {
  if (isset($_GET['eventname2'])) {
    // get event from database
    $id = $_GET['eventname2'];
    $sql = "SELECT * FROM hotel WHERE  `eventname2` = '$id' ; ";

    $result = $con->query($sql);
    if (!$result) {
      die("Invalid query!");
    }
    $row = $result->fetch_assoc();
  }
} else {
  $id = $_GET['eventname2'];
  $ename = $_POST["eventname2"];
  $local = $_POST["local2"];
  $price = $_POST["price2"];
  // echo json_encode($_POST);
  // die;
  $sql = "UPDATE `hotel` SET `eventname2`='$ename',`local2`='$local',`price2`='$price' WHERE `eventname2` = '$id'";
  // echo $sql;
  // die;
  $result = $con->query($sql);
  // echo json_encode($result);
  header('location: hotel.php');
  exit;
}

?>
<!DOCTYPE html>
<html>

<head>
  <title>Update</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" class="fw-bold">
    <div class="container-fluid">
      <a class="navbar-brand" href="hotel.php">hotel</a>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="hotel.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="create hotel.php">Add New</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="col-lg-6 m-auto">

    <form method="post" action="updata hotel.php?eventname2=<?php echo $id; ?>">

      <br><br>
      <div class="card">

        <div class="card-header bg-warning">
          <h1 class="text-white text-center"> Update hotel </h1>
        </div><br>


        <label> hotel name: </label>
        <input type="text" name="eventname2" value="<?php echo $row['eventname2']; ?>" class="form-control"> <br>

        <label> (name 2): </label>
        <input type="text" name="local2" value="<?php echo $row['local2']; ?>" class="form-control"> <br>

        <label> (name 3) </label>
        <input type="text" name="price2" value="<?php echo $row['price2']; ?>" class="form-control"> <br>

        <button class="btn btn-success" type="submit" name="submit"  href="hotel.php"> Submit </button><br>
        <a class="btn btn-info" type="submit" name="cancel" href="hotel.php"> Cancel </a><br>

      </div>
    </form>
  </div>
</body>

</html>