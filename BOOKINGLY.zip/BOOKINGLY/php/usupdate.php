<?php
include 'connection.php';
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['username'])) {
        // get event from database
        $id = $_GET['username'];
        $sql = "SELECT * FROM usertable WHERE  `username` = '$id' ; ";

        $result = $con->query($sql);
        if (!$result) {
            die('Invalid query!');
        }
        $row = $result->fetch_assoc();
    }
} else {
    $id = $_GET['username'];
    $password = $_POST['password'];
    $username = $_POST['username'];
    $Email = $_POST['Email'];
    $usertype = $_POST['usertype'];
    // echo json_encode($_POST);
    // die;
    $sql = "UPDATE `usertable` SET `username`='$username',`password`='$password',`Email`='$Email',`usertype`='$usertype' WHERE `username` = '$id'";
    // echo $sql;
    // die;
    $result = $con->query($sql);
    // echo json_encode($result);
    header('location: utest.php');
    exit();
}
?>
<!DOCTYPE html>
<html>

<head>
  <title>Update</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" class="fw-bold">
    <div class="container-fluid">
      <a class="navbar-brand" href="test.php">system</a>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="utest.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="ucreate.php">Add New</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="col-lg-6 m-auto">

    <form method="post" action="usupdate.php?username=<?php echo $id; ?>">

      <br><br>
      <div class="card">

        <div class="card-header bg-warning">
          <h1 class="text-white text-center"> Update Member </h1>
        </div><br>


        <label> username: </label>
        <input type="text" name="username" value="<?php echo $row[
            'username'
        ]; ?>" class="form-control"> <br>

        <label> password: </label>
        <input type="text" name="password" value="<?php echo $row[
            'password'
        ]; ?>" class="form-control"> <br>

        <label> Email </label>
        <input type="text" name="Email" value="<?php echo $row[
            'Email'
        ]; ?>" class="form-control"> <br>

        <label> usertype </label>
        <input type="text" name="usertype" value="<?php echo $row[
            'usertype'
        ]; ?>" class="form-control"> <br>

        <button class="btn btn-success" type="submit" name="submit"> Submit </button><br>
        <a class="btn btn-info" type="submit" name="cancel" href="utest.php"> Cancel </a><br>

      </div>
    </form>
  </div>
</body>

</html>