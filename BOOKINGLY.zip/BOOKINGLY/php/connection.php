<?php
error_reporting(E_ERROR | E_PARSE);
$hostname = "localhost";
$username = "root";
$password = "";
$databse = "resvartion";
$html = "";
$con =  mysqli_connect($hostname, $username, $password, $databse);
if ($con->connect_errno) {
    die("not connected" . $con->connect_errno);

}




?>