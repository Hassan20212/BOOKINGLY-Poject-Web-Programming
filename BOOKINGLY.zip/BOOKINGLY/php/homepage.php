<?php
// if ($_SERVER["REQUEST_METHOD"] == "POST") {
//   include "connection.php";
//   $eventname = $_POST['eventname'];
//   $username = $_POST['username'];
//   $sql = " INSERT INTO `userevents` (`eventname`, `username`) VALUES ( '$eventname', '$username' )";
//   $query = mysqli_query($con, $sql);
//   header("Location: homepage.php?username=$username");
//   die();
// }

?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  <title>Hotel</title>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand">User</a>
      <a class="nav-link active" aria-current="page"  style="color: aliceblue;" href="homepage.php">Home</a>
      <a class="nav-link active" aria-current="page" style="color: aliceblue;" href="login.php">Logout</a>
      <a class="nav-link active" aria-current="page" style="color: aliceblue;" href="homepage.php">Hotel</a>
      <a class="nav-link active" aria-current="page" style="color: aliceblue;"href="welcome.php">Flight</a>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <!-- <a class="nav-link active" aria-current="page" href="homepage.php">Home</a>
            <a class="nav-link active" aria-current="page" href="login.php">Logout</a> -->
          <!-- </li>

          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="contactus.html">Contact Us</a>
          </li> -->

        </ul>
      </div>
    </div>
  </nav>
  <div class="container my-4">
    <div class="row">
      <div class="col-6">
        <form method="post">
          <input type="hidden" name="username" value="<?php echo $_GET['username']; ?>" />
          <select name="eventname" class="form-select" />
          <?php
          include "connection.php";
          $sql = "SELECT * FROM eventtable ";
          $result = $con->query($sql, $conn);
          if (!$result) {
            die("Invalid query!");
          }
          while ($row = $result->fetch_assoc()) {
            echo "<option value='$row[eventname]'>$row[eventname]</option>";
          }
          ?>
          </select>

          <br>
          <button type="submit" class="btn btn-outline-success">Reserve</button>
        </form>

      </div>
      <div class="col-6">
        <table class="table table-striped table-bordered text-center">
          <thead>
            <tr>
              <th>Form</th>
              <th>Deletion</th>
              <th>to</th>
              <th>Price </th>

            </tr>
          </thead>
          <tbody>
            <?php
            // include "connection.php";
            $sql = "SELECT * FROM userevents where `username` = '$_GET[username]' ";
            $result = $con->query($sql, $conn);
            if (!$result) {
              die("Invalid query!");
            }
            while ($row = $result->fetch_assoc()) {
              echo "
      <tr>
        <td>$row[eventname]</td>
        <td>
                  <a class='btn btn-danger' href='H.php?eventname=$row[eventname]'>Delete</a>
                </td>
      </tr>
      ";
            }
            ?>



          </tbody>
        </table>

      </div>
    </div>
  </div>

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
</body>

</html>