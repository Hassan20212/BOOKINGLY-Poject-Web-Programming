<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  <title>Reservation System</title>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand">Add Flight</a>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <!-- <a class="nav-link active" aria-current="page" href="test.php">Events</a> -->
            <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Hotel.php">Hotel</a>
          </li>
          <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Flight.php">Flight</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="utest.php">Users</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="login.php">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="container my-4">
    <div class="row">
      <div class="col-12">
        <a type="button" class="btn btn-outline-primary" href="create Flight.php">Add Flight</a>
        <br>
        <br>

        <table class="table table-striped table-bordered text-center">
          <thead>
            <tr>
              <th>Flight From</th>
              <th>Flight To</th>
              <th>Class</th>
              <th>Price</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            include "connection.php";
            $sql = "SELECT * FROM eventtable ";
            $result = $con->query($sql, $conn);
            if (!$result) { //$row=mysqli_fetch_array($result)
              die("Invalid query!");
            }
            while ($row = $result->fetch_assoc()) {
              echo "
      <tr>
        <td>$row[eventname]</td>
        <td>$row[local]</td>
        <td>$row[price]</td>
        <td>$row[seat]</td>
        <td>$row[class]</td>
        <td>
                  <a class='btn btn-success' href='update.php?eventname=$row[eventname]'>Edit</a>
                  <a class='btn btn-danger' href='delete.php?eventname=$row[eventname]'>Delete</a>
                </td>
      </tr>
      ";
            }
            ?>
          </tbody>
        </table>

      </div>
    </div>
  </div>

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>