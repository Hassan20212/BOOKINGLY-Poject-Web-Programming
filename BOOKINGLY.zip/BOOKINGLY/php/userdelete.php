<?php
    include "connection.php";
    if(isset($_GET['username'])){
        $id = $_GET['username'];
        $sql = "DELETE FROM `usertable` WHERE username ='$id' " ;
        // $conn->query($sql);
        if (mysqli_query($con, $sql)) {
            echo "Record deleted successfully";
        } else {
            echo "Error deleting record: " . mysqli_error($con);
            echo $sql;
        }
        
    }
    header('location:utest.php');
    exit;
?>