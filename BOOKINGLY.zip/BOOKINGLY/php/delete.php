<?php
    include "connection.php";
    if(isset($_GET['eventname'])){
        $id = $_GET['eventname'];
        $sql = "DELETE FROM eventtable WHERE  `eventname` = '$id'" ;
        // $conn->query($sql);
        if (mysqli_query($con, $sql)) {
            echo "Record deleted successfully";
        } else {
            echo "Error deleting record: " . mysqli_error($con);
        }
        
    }
    header('location: Flight.php');
    exit;
?>