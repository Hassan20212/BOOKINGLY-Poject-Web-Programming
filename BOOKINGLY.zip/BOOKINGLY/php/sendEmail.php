﻿<?php
   require 'includes\PHPMailer.php';
   require 'includes\Exception.php';
   require 'includes\SMTP.php';

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;




function url(){
  return sprintf(
    "%s://%s",
    isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
    $_SERVER['SERVER_NAME']
  );
}

if(($_POST) ){

   $name = trim(stripslashes($_POST['name']));  
   $email = trim(stripslashes($_POST['email']));
   $subject = trim(stripslashes($_POST['subject']));
   $message = trim(stripslashes($_POST['message']));


   $mail = new PHPMailer(true);
   $mail -> isSMTP();
   $mail -> SMTPAuth = "true";
   $mail -> Host = "smtp-relay.sendinblue.com";
   $mail -> SMTPSecure = 'tls';
   $mail -> Port = 587;
   $mail -> Username = "hassannabil1990@gmail.com";
   $mail -> Password = "USkahH6xwmc70dTf";
   $mail -> setFrom ($email , $name);
   $mail -> addAddress("hassannabil1990@hotmail.com","Hassan Nabil");
   $mail -> Subject = $subject;
   $mail -> Body = $message;
   $mail -> send();

    if ($mail) { echo "OK"; }
   else { echo "Something went wrong. Please try again."; }

}

?>