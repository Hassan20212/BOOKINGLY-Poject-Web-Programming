<?php
include "connection.php";
if ($_SERVER["REQUEST_METHOD"] == "GET") {
  if (isset($_GET['eventname'])) {
    // get event from database
    $id = $_GET['eventname'];
    $sql = "SELECT * FROM eventtable WHERE  `eventname` = '$id' ; ";

    $result = $con->query($sql);
    if (!$result) {
      die("Invalid query!");
    }
    $row = $result->fetch_assoc();
  }
} else {
  $id = $_GET['eventname'];
  $ename = $_POST["eventname"];
  $local = $_POST["local"];
  $price = $_POST["price"];
  $seat = $_POST["seat"];
  $class = $_POST["class"];

  
  // echo json_encode($_POST);
  // die;
  $sql = "UPDATE `eventtable` SET `eventname`='$ename',`local`='$local',`price`='$price',`seat`='$seat' ,`class`='$class'   WHERE `eventname` = '$id'";
  // echo $sql;
  // die;
  $result = $con->query($sql);
  // echo json_encode($result);
  header('location: Flight.php');
  exit;
}

?>
<!DOCTYPE html>
<html>

<head>
  <title>Update</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" class="fw-bold">
    <div class="container-fluid">
      <a class="navbar-brand" href="Flight.php">PHP CRUD OPERATION</a>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="Flight.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="create.php">Add New</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="col-lg-6 m-auto">

    <form method="post" action="update.php?eventname=<?php echo $id; ?>">

      <br><br>
      <div class="card">

        <div class="card-header bg-warning">
          <h1 class="text-white text-center"> Update Member </h1>
        </div><br>


        <label> eventname: </label>
        <input type="text" name="eventname" value="<?php echo $row['eventname']; ?>" class="form-control"> <br>

        <label> local: </label>
        <input type="text" name="local" value="<?php echo $row['local']; ?>" class="form-control"> <br>

        <label> price </label>
        <input type="text" name="price" value="<?php echo $row['price']; ?>" class="form-control"> <br>

        <label> seat </label>
        <input type="text" name="seat" value="<?php echo $row['seat']; ?>" class="form-control"> <br>

        <label> class </label>
        <input type="text" name="class" value="<?php echo $row['class']; ?>" class="form-control"> <br>

        <button class="btn btn-success" type="submit" name="submit"  href="Flight.php"> Submit </button><br>
        <a class="btn btn-info" type="submit" name="cancel" href="Flight.php"> Cancel </a><br>

      </div>
    </form>
  </div>
</body>

</html>